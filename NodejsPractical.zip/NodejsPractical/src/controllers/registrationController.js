const Registration = require('../models/registrationModel'); // Assuming a registration model exists
const Event = require('../models/eventModel');
const User = require('../models/userModel');

// Register a user for an event
exports.registerForEvent = async (req, res) => {
    const { eventId } = req.params;
    const userId = req.user.id; // Assuming user ID is available in req.user

    try {
        const event = await Event.findById(eventId);
        if (!event) {
            return res.status(404).json({ message: 'Event not found' });
        }

        const registration = new Registration({ eventId, userId });
        await registration.save();

        res.status(201).json({ message: 'Successfully registered for the event', registration });
    } catch (error) {
        res.status(500).json({ message: 'Error registering for event', error });
    }
};

// Cancel a user's registration for an event
exports.cancelRegistration = async (req, res) => {
    const { eventId, userId } = req.params;

    try {
        const registration = await Registration.findOneAndDelete({ eventId, userId });
        if (!registration) {
            return res.status(404).json({ message: 'Registration not found' });
        }

        res.status(200).json({ message: 'Registration cancelled successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error cancelling registration', error });
    }
};