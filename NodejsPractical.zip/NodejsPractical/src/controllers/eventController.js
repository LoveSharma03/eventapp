const Event = require('../models/eventModel');

exports.createEvent = async (req, res) => {
    try {
        const { title, description, date } = req.body;
        const newEvent = new Event({ title, description, date });
        await newEvent.save();
        res.status(201).json({ message: 'Event created successfully', event: newEvent });
    } catch (error) {
        res.status(500).json({ message: 'Error creating event', error: error.message });
    }
};

exports.getAllEvents = async (req, res) => {
    try {
        const events = await Event.find();
        res.status(200).json(events);
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving events', error: error.message });
    }
};

exports.validateEventDate = (req, res, next) => {
    const { date } = req.body;
    const eventDate = new Date(date);
    const currentDate = new Date();

    if (eventDate < currentDate) {
        return res.status(400).json({ message: 'Event date must be in the future' });
    }
    next();
};