const express = require('express');
const { registerForEvent, cancelRegistration } = require('../controllers/registrationController');
const router = express.Router();

// Route to register for an event
router.post('/events/:eventId/register', registerForEvent);

// Route to cancel registration for an event
router.delete('/events/:eventId/cancel/:userId', cancelRegistration);

module.exports = router;