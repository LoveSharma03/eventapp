# Event Management App

This is a web application that allows users to manage and register for events. It includes user registration and login functionality, event creation, registration, viewing registered events, and cancellation of registrations.

## Features

- User Registration and Login
- Event Creation and Management
- User Registration for Events
- View Registered Events
- Cancel Event Registrations

## Project Structure

```
event-management-app
├── src
│   ├── app.js
│   ├── controllers
│   │   ├── authController.js
│   │   ├── eventController.js
│   │   └── registrationController.js
│   ├── models
│   │   ├── userModel.js
│   │   └── eventModel.js
│   ├── routes
│   │   ├── authRoutes.js
│   │   ├── eventRoutes.js
│   │   └── registrationRoutes.js
│   ├── middlewares
│   │   └── authMiddleware.js
│   ├── utils
│   │   └── db.js
│   └── views
│       └── index.html
├── package.json
├── .env
├── .gitignore
└── README.md
```

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd event-management-app
   ```

3. Install the dependencies:
   ```
   npm install
   ```

4. Set up your environment variables in the `.env` file.

## Usage

1. Start the application:
   ```
   npm start
   ```

2. Access the application in your web browser at `http://localhost:3000`.

## API Endpoints

### Authentication Routes
- `POST /api/auth/register`: Register a new user.
- `POST /api/auth/login`: Log in an existing user.

### Event Routes
- `POST /api/events`: Create a new event.
- `GET /api/events`: Retrieve all upcoming events.

### Registration Routes
- `POST /api/events/:eventId/register`: Register for an event.
- `DELETE /api/events/:eventId/cancel/:userId`: Cancel registration for an event.

## License

This project is licensed under the MIT License.